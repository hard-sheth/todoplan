export class Constants {
  public static NotFoundMessage = `Sorry! No More Record Found`;
}

export const NotFoundMessage = `Sorry! No More Record Found`;
